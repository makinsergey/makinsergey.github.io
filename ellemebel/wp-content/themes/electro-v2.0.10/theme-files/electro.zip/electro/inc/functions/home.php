<?php
/**
 * Functions used in different homepages
 */

require_once get_template_directory() . '/inc/functions/homepages/home-v1.php';
require_once get_template_directory() . '/inc/functions/homepages/home-v2.php';
require_once get_template_directory() . '/inc/functions/homepages/home-v3.php';
require_once get_template_directory() . '/inc/functions/homepages/home-v4.php';
require_once get_template_directory() . '/inc/functions/homepages/home-v5.php';
require_once get_template_directory() . '/inc/functions/homepages/home-mobile-v1.php';
require_once get_template_directory() . '/inc/functions/homepages/home-mobile-v2.php';